/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication40;

import java.util.ArrayList;
import javax.swing.JOptionPane;


public class Sales {
    
String  nombre;



Sales(String nombre)
 {
    this.nombre = nombre; 
 }

public void setNombre(String nombre)
{
    this.nombre = nombre;
}


public static void main(String args[])
{
    ArrayList<Sales> list = new  ArrayList<Sales>();
    String opcion;   
    boolean corre = true;
    
    while(corre){
            
     opcion = JOptionPane.showInputDialog   ("1.  Ingresar Nombre Usuario \n"
                                            +"2.  Eliminar Usuario \n"
                                            +"3.  Buscar Usuario \n"
                                            +"4.  Mostrar Lista \n"
                                            +"5.  Modificar Nombre Usuario \n"
                                            +"6.  Borrar Lista \n"
                                            +"7.  Salir \n");
     
     
     
     
    
     String listado = "";  
     
     switch(opcion){
           
      case "1":
                  
               String  nombre = JOptionPane.showInputDialog(" Digite Nombre ");
               list.add(new Sales(nombre)); 
               
               for(int i=0; i<list.size(); i++)
               {
                    listado +=  (i+1)+ " NOMBRE: " + list.get(i).nombre + "\n"; 
               }  
               
                JOptionPane.showMessageDialog(null,listado + "\n");
                
               break;
          
          
          
          
      case "2":
          
                    for(int i=0; i<list.size(); i++)
                        {
                            listado +=  (i+1)+ " NOMBRE: " + list.get(i).nombre + "\n"; 
                        }  
                        JOptionPane.showMessageDialog(null,listado + "\n");
          
          
            
              String  borrar = JOptionPane.showInputDialog(" Digite nombre para borrar ");
              
              for(int i=0; i<list.size(); i++)
              {
               if(list.get(i).nombre.equals(borrar))                
                 list.remove(i);
              }  
                    
                    
               for( int i = 0 ; i  < list.size(); i++)
                   {
                     listado +=  (i+1)+ "º- " + " NOMBRE: " + list.get(i).nombre + "\n"; 
                   }
                    JOptionPane.showMessageDialog(null, listado); 
                    
                break; 
     
          
       case "3":
                   
               String resultado  = "SIN DATO"; 
                          
               String searched_nombre = JOptionPane.showInputDialog(" Buscar usuario ");
                         
               for( int i = 0 ; i  < list.size(); i++)
                {
                  if(list.get(i).nombre.equals(searched_nombre))
                    {
                     resultado  ="";
                                
                     resultado +=  " NOMBRE: " + list.get(i).nombre  + "\n"; 
                 }
              }
               
               JOptionPane.showMessageDialog(null, resultado);
                         
                     break; 
          
          
          
          
      case "4":
                    
                if(!list.isEmpty())
                 {
                   for( int i = 0 ; i  < list.size(); i++)
                   {
                    listado +=  (i+1)+ " NOMBRE: " + list.get(i).nombre + "\n"; 
                   }
                    JOptionPane.showMessageDialog(null, listado); 
                    
                 }else{
                        JOptionPane.showMessageDialog(null, " LISTA VACIA ", "", JOptionPane.WARNING_MESSAGE); 
                      }
                
                break; 
          

      case "5":
                   
                 String  modificar = JOptionPane.showInputDialog("Nombre a modificar");
                          
                 String  new_nombre = JOptionPane.showInputDialog("Ingrese Nuevo Dato ");
                 
                 
                 for(int i=0; i<list.size(); i++)
                  {
                   if(list.get(i).nombre.equals(modificar))
                    {
                     list.get(i).setNombre(new_nombre);
                                          
                     listado +=  (i+1)+ "º- " + " NOMBRE:       " + list.get(i).nombre; 
                     
                     JOptionPane.showMessageDialog(null, listado);
                     }
                   }
                 
                  break;
          
          
      case "6":
                   
                 list.clear();
                 
                 JOptionPane.showMessageDialog(null, " Lista vacia ", "", JOptionPane.WARNING_MESSAGE); 
                     
                 break;
                   
                   
      
      case "7":
                   
                corre = false;
                     
                break;
                    
      default: 
                   
               JOptionPane.showMessageDialog(null, "Opcion no correcta ");
               
               break;
           }      
       }
   }
}

